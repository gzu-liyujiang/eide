int main()
{
	__builtin_printf( "Hello World!");
    return 0;
}
