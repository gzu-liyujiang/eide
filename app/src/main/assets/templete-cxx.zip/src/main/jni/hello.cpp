#include <stdio.h>
#include <stdint.h>

int main()
{
	printf( "Hello World!");
    return 0;
}
